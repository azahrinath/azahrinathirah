﻿Public Class GlobalVariables
    Public Shared CurrentUsername As String
End Class